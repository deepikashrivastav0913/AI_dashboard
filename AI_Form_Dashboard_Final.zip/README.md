# AI Form Dashboard MVP

Demo Login:
admin@demo.com
Password: any value

Open index.html and login.
Flow: Login -> Dashboard -> Form Builder -> Preview -> Public Form -> Analytics.
No installation required.